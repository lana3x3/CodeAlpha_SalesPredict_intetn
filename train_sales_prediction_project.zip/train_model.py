
import pandas as pd
import joblib
from sklearn.linear_model import LinearRegression

# Read the dataset
df = pd.read_csv("Advertising.csv")

# Drop the unwanted column
if "Unnamed: 0" in df.columns:
    df = df.drop("Unnamed: 0", axis=1)

# Apply One-Hot Encoding for Platform and Segment
df = pd.get_dummies(df, columns=["Platform", "Segment"])

# Prepare data for training
X = df.drop("Sales", axis=1)
y = df["Sales"]

# Save the feature columns
joblib.dump(X.columns.tolist(), "model_columns.pkl")

# Train the model
model = LinearRegression()
model.fit(X, y)

# Save the trained model
joblib.dump(model, "sales_model.pkl")
